--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = address, pg_catalog;

--
-- Data for Name: address; Type: TABLE DATA; Schema: address; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE address DISABLE TRIGGER ALL;

INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('3084f4d3-494a-4b3e-86ad-0e8a9c8e1d1f', 'strada mia', NULL, 'dee1e7dd-ec84-4af3-b42a-e74882037b3b', 1, 'i', 'test', '2016-04-05 07:28:10.548');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('2c15a660-008e-4fe1-9d75-3fd675ac8843', 'vghvghv', NULL, '09c3e282-040b-4229-8daa-68fbe66426e6', 1, 'i', 'test', '2016-04-05 16:54:16.748');


ALTER TABLE address ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

