--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = transaction, pg_catalog;

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: transaction; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE transaction DISABLE TRIGGER ALL;

INSERT INTO transaction (id, from_service_id, status_code, approval_datetime, bulk_generate_first_part, is_bulk_operation, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('3e643eb3-68a4-411a-87da-03ac071de5c8', '6009bb3a-f31c-446a-aa13-3d928822135e', 'pending', NULL, false, false, '882ceb05-d485-4635-8f96-b1027d0df366', 14, 'u', 'test', '2016-04-06 18:48:37.237');


ALTER TABLE transaction ENABLE TRIGGER ALL;

--
-- Data for Name: transaction_source; Type: TABLE DATA; Schema: transaction; Owner: postgres
--

ALTER TABLE transaction_source DISABLE TRIGGER ALL;



ALTER TABLE transaction_source ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

