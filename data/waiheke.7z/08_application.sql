--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = application, pg_catalog;

--
-- Data for Name: application; Type: TABLE DATA; Schema: application; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE application DISABLE TRIGGER ALL;

INSERT INTO application (id, nr, agent_id, contact_person_id, lodging_datetime, expected_completion_date, assignee_id, assigned_datetime, location, services_fee, tax, total_fee, total_amount_paid, fee_paid, action_code, action_notes, status_code, receipt_reference, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('6bc61298-854a-4dd8-afa9-183af83225ce', '16040001', NULL, '0f3e62c1-10e2-4164-bd7a-9a914f1b0437', '2016-04-05 07:28:10.825', '2016-05-05', 'test-id', '2016-04-05 07:40:05.821', NULL, 25.00, 1.88, 26.88, 26.88, true, 'assign', NULL, 'lodged', NULL, '7c8bb51f-a10f-4095-8676-80b1289dc465', 3, 'u', 'test', '2016-04-05 07:40:05.817', NULL, NULL);
INSERT INTO application (id, nr, agent_id, contact_person_id, lodging_datetime, expected_completion_date, assignee_id, assigned_datetime, location, services_fee, tax, total_fee, total_amount_paid, fee_paid, action_code, action_notes, status_code, receipt_reference, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('f2109607-447c-40e3-b162-cf553154da0a', '16040002', NULL, '6324b8c5-bc4b-4c28-9eba-d58ef1ea1377', '2016-04-05 16:54:16.78', '2016-05-05', 'test-id', '2016-04-06 12:01:51.527', NULL, 25.00, 1.88, 26.88, 26.88, true, 'assign', NULL, 'lodged', NULL, '76cbc5a4-4bbb-4fc6-a793-dda872f3cd68', 4, 'u', 'test', '2016-04-06 12:01:51.527', NULL, NULL);


ALTER TABLE application ENABLE TRIGGER ALL;

--
-- Data for Name: application_property; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE application_property DISABLE TRIGGER ALL;

INSERT INTO application_property (id, application_id, name_firstpart, name_lastpart, area, total_value, verified_exists, verified_location, ba_unit_id, land_use_code, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('f35c6854-338d-416b-8dc4-2369c4e751c3', '6bc61298-854a-4dd8-afa9-183af83225ce', 'LS 770', '14', 0.00, 0.00, false, false, NULL, NULL, '71b207c9-62bb-40eb-bddb-d4f249eda27d', 1, 'i', 'test', '2016-04-05 07:39:32.231');
INSERT INTO application_property (id, application_id, name_firstpart, name_lastpart, area, total_value, verified_exists, verified_location, ba_unit_id, land_use_code, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('e3203d84-e76b-4ebc-b113-5b50130fa13e', 'f2109607-447c-40e3-b162-cf553154da0a', 'LS 104', '22', 0.00, 0.00, false, false, NULL, NULL, '5b518ba1-7376-4e67-87fa-ca92c2a6de44', 1, 'i', 'test', '2016-04-05 16:54:16.748');


ALTER TABLE application_property ENABLE TRIGGER ALL;

--
-- Data for Name: application_spatial_unit; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE application_spatial_unit DISABLE TRIGGER ALL;



ALTER TABLE application_spatial_unit ENABLE TRIGGER ALL;

--
-- Data for Name: service; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE service DISABLE TRIGGER ALL;

INSERT INTO service (id, application_id, request_type_code, service_order, lodging_datetime, expected_completion_date, status_code, action_code, action_notes, base_fee, area_fee, value_fee, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('332c9e4f-3e1b-4db1-9e71-b8b70b702b3a', '6bc61298-854a-4dd8-afa9-183af83225ce', 'cadastreChange', 1, '2016-04-05 07:28:10.825', '2016-05-05', 'pending', 'start', NULL, 25.00, 0.00, 0.00, '00d3c611-c1e3-4a89-9b0f-92ed837ad46e', 2, 'u', 'test', '2016-04-05 07:40:14.896');
INSERT INTO service (id, application_id, request_type_code, service_order, lodging_datetime, expected_completion_date, status_code, action_code, action_notes, base_fee, area_fee, value_fee, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('a23bd9d5-c260-4741-9974-68d1c8804c94', '6bc61298-854a-4dd8-afa9-183af83225ce', 'cadastrePrint', 0, '2016-04-05 17:16:22.501', '2016-04-05', 'completed', 'complete', NULL, 0.00, 0.00, 0.00, 'ff7955f3-e090-4c19-8f82-587341a9cafe', 2, 'u', 'test', '2016-04-05 17:16:22.25');
INSERT INTO service (id, application_id, request_type_code, service_order, lodging_datetime, expected_completion_date, status_code, action_code, action_notes, base_fee, area_fee, value_fee, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('6009bb3a-f31c-446a-aa13-3d928822135e', 'f2109607-447c-40e3-b162-cf553154da0a', 'cadastreChange', 1, '2016-04-05 16:54:16.78', '2016-05-05', 'pending', 'start', NULL, 25.00, 0.00, 0.00, 'fae4df66-6834-4a30-b9ca-49f2aecf75e0', 2, 'u', 'test', '2016-04-06 14:53:24.733');


ALTER TABLE service ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

