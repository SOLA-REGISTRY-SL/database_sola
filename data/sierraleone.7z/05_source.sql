--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = source, pg_catalog;

--
-- Data for Name: archive; Type: TABLE DATA; Schema: source; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE archive DISABLE TRIGGER ALL;



ALTER TABLE archive ENABLE TRIGGER ALL;

--
-- Data for Name: source; Type: TABLE DATA; Schema: source; Owner: postgres
--

ALTER TABLE source DISABLE TRIGGER ALL;

INSERT INTO source (id, maintype, la_nr, reference_nr, archive_id, acceptance, recordation, submission, expiration_date, ext_archive_id, availability_status_code, type_code, content, status_code, transaction_id, owner_name, version, description, signing_date, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('1459f701-4f5c-41a6-9ce6-ee37c2106fa5', NULL, '160405-000000001', NULL, NULL, NULL, '2016-04-01', '2016-04-05', NULL, '6defe7dc-d206-4959-b01e-38bfec494005', 'available', 'cadastralSurvey', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5333ec1b-f4ce-4614-a570-119029bcc98f', 1, 'i', 'test', '2016-04-05 07:39:04.775', NULL, NULL);
INSERT INTO source (id, maintype, la_nr, reference_nr, archive_id, acceptance, recordation, submission, expiration_date, ext_archive_id, availability_status_code, type_code, content, status_code, transaction_id, owner_name, version, description, signing_date, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('7a661126-06a1-43dc-8bb8-420e1683e832', NULL, '160405-000000002', NULL, NULL, NULL, '2016-04-05', '2016-04-05', NULL, 'e6abacec-f4c3-4d2e-bed5-5a0d3035bca8', 'available', 'cadastralSurvey', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2999fcbb-a4b9-4299-8145-7bd8822837f9', 1, 'i', 'test', '2016-04-05 09:15:02.18', NULL, NULL);
INSERT INTO source (id, maintype, la_nr, reference_nr, archive_id, acceptance, recordation, submission, expiration_date, ext_archive_id, availability_status_code, type_code, content, status_code, transaction_id, owner_name, version, description, signing_date, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('c003a85b-979d-4dbc-be2d-34c9110f53e2', NULL, '160405-000000003', NULL, NULL, NULL, '2016-04-01', '2016-04-05', NULL, '0960b1b9-e905-406c-810b-1d08e29f6d53', 'available', 'cadastralSurvey', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '496638e5-6136-404d-8fb9-05a48f1068a0', 1, 'i', 'test', '2016-04-05 16:54:16.748', NULL, NULL);


ALTER TABLE source ENABLE TRIGGER ALL;

SET search_path = administrative, pg_catalog;

--
-- Data for Name: source_describes_ba_unit; Type: TABLE DATA; Schema: administrative; Owner: postgres
--

ALTER TABLE source_describes_ba_unit DISABLE TRIGGER ALL;



ALTER TABLE source_describes_ba_unit ENABLE TRIGGER ALL;

--
-- Data for Name: source_describes_rrr; Type: TABLE DATA; Schema: administrative; Owner: postgres
--

ALTER TABLE source_describes_rrr DISABLE TRIGGER ALL;



ALTER TABLE source_describes_rrr ENABLE TRIGGER ALL;

SET search_path = application, pg_catalog;

--
-- Data for Name: application_uses_source; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE application_uses_source DISABLE TRIGGER ALL;

INSERT INTO application_uses_source (application_id, source_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('6bc61298-854a-4dd8-afa9-183af83225ce', '7a661126-06a1-43dc-8bb8-420e1683e832', '6e9bbd5d-bdf9-4b1e-8c97-bfc5b09d1876', 1, 'i', 'test', '2016-04-05 09:15:02.18');
INSERT INTO application_uses_source (application_id, source_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('f2109607-447c-40e3-b162-cf553154da0a', 'c003a85b-979d-4dbc-be2d-34c9110f53e2', 'dbca7396-c7d3-45d6-a761-82e51e9fe418', 1, 'i', 'test', '2016-04-05 16:54:16.748');


ALTER TABLE application_uses_source ENABLE TRIGGER ALL;

SET search_path = source, pg_catalog;

--
-- Data for Name: power_of_attorney; Type: TABLE DATA; Schema: source; Owner: postgres
--

ALTER TABLE power_of_attorney DISABLE TRIGGER ALL;



ALTER TABLE power_of_attorney ENABLE TRIGGER ALL;

--
-- Data for Name: spatial_source; Type: TABLE DATA; Schema: source; Owner: postgres
--

ALTER TABLE spatial_source DISABLE TRIGGER ALL;



ALTER TABLE spatial_source ENABLE TRIGGER ALL;

--
-- Data for Name: spatial_source_measurement; Type: TABLE DATA; Schema: source; Owner: postgres
--

ALTER TABLE spatial_source_measurement DISABLE TRIGGER ALL;



ALTER TABLE spatial_source_measurement ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

