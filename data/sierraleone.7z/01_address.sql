--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.4
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = address, pg_catalog;

--
-- Data for Name: address; Type: TABLE DATA; Schema: address; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE address DISABLE TRIGGER ALL;

INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161131', 'C/O TECHSULT 26 PERCIVAL STREET, FREETOWN', 'NA', 'c7938388-31a7-11e6-adc2-b7643cbd72b9', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161132', 'C/O SIERRA RUTILE P.O. BOX 59, FREETOWN', 'na', 'c7981768-31a7-11e6-adc5-573c28f8417f', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161133', '8A MUDGE FARM, MURRAY TOWN, FREETOWN', 'na', 'c798176b-31a7-11e6-adc8-17136759f6a8', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161134', '13 DAVIS STREET, KISSY', 'na', 'c7999e09-31a7-11e6-adcb-ef6adde16f30', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161135', '17D NEWCASTLE STREET, KISSY', 'na', 'c7999e0c-31a7-11e6-adce-33ff0ad9678a', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161136', '21 MURRAY TOWN ROAD, MURRAY TOWN, FREETOWN', 'na', 'c7999e0f-31a7-11e6-add1-efab7a81c958', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161137', '3 UPPER SAVAGE SQUARE, FREETOWN', 'na', 'c79b24a9-31a7-11e6-add4-5b32a60004fb', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161138', 'SIEROMCO MINES P.O. BOX 725, FREETOWN', 'na', 'c79b24ac-31a7-11e6-add7-2f41e15bccc6', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161139', 'SIERRA RUTILE LTD. P.O. BOX 59, FREETOWN', 'na', 'c79b24af-31a7-11e6-adda-37bdc04f9e0e', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161140', '45 BATHURST STREET, FREETOWN', 'na', 'c79cab49-31a7-11e6-addd-535a961dc2d5', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161141', '67 BASS STREET, BROOKFIELDS, FREETOWN', 'na', 'c79cab4c-31a7-11e6-ade0-07fb5a929ceb', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161142', 'C/O SPIRITUS HOUSE, 5 HOWE STREET, FREETOWN', 'na', 'c79cab4f-31a7-11e6-ade3-0bb6573d9122', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161143', '40A LOW COST HOUSING ESTATE, KISSY, FREETOWN', 'na', 'c79e31e8-31a7-11e6-ade6-2378f0ee7854', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161144', '11 MANNER STREET, ALLEN TOWN', 'na', 'c79e31eb-31a7-11e6-ade9-636e82347723', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161145', '27 CEMENTRY ROAD, ORUGU VILLAGE, ALLEN TOWN', 'na', 'c79e31ee-31a7-11e6-adec-1b992b79b1af', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161146', '22 LEAH STREET, FREETOWN', 'na', 'c79fb888-31a7-11e6-adef-1bdeaf75b184', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161147', '26 GODERICH ROAD, LUMLEY, FREETOWN', 'na', 'c79fb88b-31a7-11e6-adf2-af97a6d2862c', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161148', '13D HANNESSON STREET, NEW ENGLAND, FREETOWN', 'na', 'c79fb88e-31a7-11e6-adf5-fb1cbd790390', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161149', '6 SAMUELS LAND, KISSY', 'na', 'c79fb891-31a7-11e6-adf8-773c898af482', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161150', '9F KINGHARMAN ROAD, BROOKFIELDS, FREETOWN', 'na', 'c7a13f2a-31a7-11e6-adfb-1b917ff89429', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161151', '6 SAWI DRIVE OFF KINGHARMAN ROAD, P.O. BOX 799, FREETOWN', 'na', 'c7a13f2d-31a7-11e6-adfe-c3813b442ba0', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161152', '168A CIRCULAR ROAD, FREETOWN', 'na', 'c7a13f30-31a7-11e6-ae01-634bbe092e02', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161153', '40 SUMAILA TOWN OFF PADEMBA ROAD, FREETOWN', 'na', 'c7a2c5c9-31a7-11e6-ae04-ab009892b057', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161154', 'PASSANDI HOUSE, CANTONMENT ROAD, BROOKFIELDS, FREETOWN', 'na', 'c7a2c5cc-31a7-11e6-ae07-5f75bc0fb794', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161155', 'KENEMA', 'na', 'c7a2c5cf-31a7-11e6-ae0a-ab65148461db', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161156', '14A ANSLEY STREET, FREETOWN', 'na', 'c7a44c69-31a7-11e6-ae0d-ab32f6dc38f4', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161157', '19A BOYLE LAND, BANAWA WATER, MURRAY TOWN, FREETOWN', 'na', 'c7a44c6c-31a7-11e6-ae10-03ce0c97b81f', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161158', 'na', 'na', 'c7a44c6f-31a7-11e6-ae13-938735e09a0c', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161159', '3 PETER STREET, OFF MOUNTAIN CUT, FREETOWN', 'na', 'c7a5d308-31a7-11e6-ae16-2f4b8979fe2e', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161160', '67 BASS STREET, BROOKFIELDS, FREETOWN', 'na', 'c7a5d30b-31a7-11e6-ae19-ef79a3b26f8d', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161161', '18 PETER LANE, FREETOWN', 'na', 'c7a5d30e-31a7-11e6-ae1c-130f7e14abec', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161162', '8 WHYSE MOORE STREET, PORTEE, FREETOWN', 'na', 'c7a759a8-31a7-11e6-ae1f-f340371f8ca0', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161163', 'OFF MMTC, GODERICH, FREETOWN', 'na', 'c7a759ab-31a7-11e6-ae22-2f30ee1ff513', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161164', '62 SANDER STREET, FREETOWN', 'na', 'c7a759ae-31a7-11e6-ae25-0b0efc9a4785', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161165', 'KENEMA-ISU ROAD PROJECT', 'na', 'c7a759b1-31a7-11e6-ae28-e3994d54b824', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('060520161166', 'na', 'na', 'c7aefac8-31a7-11e6-ae2b-f324fd884bb2', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161549', 'NA', 'NA', 'c7d9b456-31a7-11e6-af5c-537b75f30038', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161550', 'NA', 'NA', 'c7d9b459-31a7-11e6-af5f-2f2fa5b22a5e', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161551', 'NA', 'NA', 'c7d9b45c-31a7-11e6-af62-c7c66b7cc154', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161552', 'NA', 'NA', 'c7db3af4-31a7-11e6-af65-0bb7da2682ab', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161553', 'NA', 'NA', 'c7db3af7-31a7-11e6-af68-7f74630476bf', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161554', 'NA', 'NA', 'c7db3afa-31a7-11e6-af6b-0fbaaf98b818', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161555', 'NA', 'NA', 'c7e2dc12-31a7-11e6-af71-eb036896d063', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161556', 'NA', 'NA', 'c7e2dc15-31a7-11e6-af74-ef94478555ac', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161557', 'NA', 'NA', 'c7e462b4-31a7-11e6-af77-3754decbc763', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161558', 'NA', 'NA', 'c7e462b7-31a7-11e6-af7a-df1349641bc7', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161559', 'NA', 'NA', 'c7e462ba-31a7-11e6-af7d-f3209baeae07', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161560', 'NA', 'NA', 'c7e5e952-31a7-11e6-af80-8786749a5b48', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161561', 'NA', 'NA', 'c7e5e955-31a7-11e6-af83-d7fc86cfa065', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161562', 'NA', 'NA', 'c7e5e958-31a7-11e6-af86-6b8ecf2b2038', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161563', 'NA', 'NA', 'c7e5e95b-31a7-11e6-af89-2b6598939d7d', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161564', 'NA', 'NA', 'c7e76ff3-31a7-11e6-af8c-6f30b6b0e38c', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161565', 'NA', 'NA', 'c7e76ff6-31a7-11e6-af8f-5b01014335f0', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161566', 'NA', 'NA', 'c7e76ff9-31a7-11e6-af92-5f2bcbedf745', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');
INSERT INTO address (id, description, ext_address_id, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('080620161567', 'NA', 'NA', 'c7e76ffc-31a7-11e6-af95-6fe2866be731', 1, 'i', 'db:postgres', '2016-06-13 22:45:35.881');


ALTER TABLE address ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

