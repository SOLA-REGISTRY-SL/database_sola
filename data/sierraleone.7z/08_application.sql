--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = application, pg_catalog;

--
-- Data for Name: application; Type: TABLE DATA; Schema: application; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE application DISABLE TRIGGER ALL;



ALTER TABLE application ENABLE TRIGGER ALL;

--
-- Data for Name: application_property; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE application_property DISABLE TRIGGER ALL;



ALTER TABLE application_property ENABLE TRIGGER ALL;

--
-- Data for Name: application_spatial_unit; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE application_spatial_unit DISABLE TRIGGER ALL;



ALTER TABLE application_spatial_unit ENABLE TRIGGER ALL;

--
-- Data for Name: service; Type: TABLE DATA; Schema: application; Owner: postgres
--

ALTER TABLE service DISABLE TRIGGER ALL;

INSERT INTO service (id, application_id, request_type_code, service_order, lodging_datetime, expected_completion_date, status_code, action_code, action_notes, base_fee, area_fee, value_fee, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('7adcc9a0-9e42-40df-9250-08ef59b68cbb', NULL, 'cadastrePrint', 0, '2016-03-14 12:20:27.47', '2016-03-14', 'completed', 'complete', NULL, 0.00, 0.00, 0.00, 'b1214255-4aa5-4212-a671-c21b1c736f1f', 2, 'u', 'test', '2016-03-14 12:20:27.245');


ALTER TABLE service ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

