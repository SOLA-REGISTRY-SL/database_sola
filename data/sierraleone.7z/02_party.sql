--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = party, pg_catalog;

--
-- Data for Name: party; Type: TABLE DATA; Schema: party; Owner: postgres
--

SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE party DISABLE TRIGGER ALL;

INSERT INTO party (id, ext_id, type_code, name, last_name, fathers_name, fathers_last_name, alias, gender_code, address_id, id_type_code, id_number, email, mobile, phone, fax, preferred_communication_code, birth_date, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('0f3e62c1-10e2-4164-bd7a-9a914f1b0437', NULL, 'naturalPerson', 'paola', 'rizzo', NULL, NULL, NULL, 'female', '3084f4d3-494a-4b3e-86ad-0e8a9c8e1d1f', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a03be6f8-3e6f-4c6c-a7e5-ce81eba0b586', 1, 'i', 'test', '2016-04-05 07:28:10.548', NULL, NULL);
INSERT INTO party (id, ext_id, type_code, name, last_name, fathers_name, fathers_last_name, alias, gender_code, address_id, id_type_code, id_number, email, mobile, phone, fax, preferred_communication_code, birth_date, rowidentifier, rowversion, change_action, change_user, change_time, classification_code, redact_code) VALUES ('6324b8c5-bc4b-4c28-9eba-d58ef1ea1377', NULL, 'naturalPerson', 'fgfgc', 'hvghv', NULL, NULL, NULL, 'female', '2c15a660-008e-4fe1-9d75-3fd675ac8843', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'd41a0aba-66f5-492f-a83d-3198c15d1bf9', 1, 'i', 'test', '2016-04-05 16:54:16.748', NULL, NULL);


ALTER TABLE party ENABLE TRIGGER ALL;

--
-- Data for Name: party_role; Type: TABLE DATA; Schema: party; Owner: postgres
--

ALTER TABLE party_role DISABLE TRIGGER ALL;

INSERT INTO party_role (party_id, type_code, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('0f3e62c1-10e2-4164-bd7a-9a914f1b0437', 'applicant', 'e1730843-4159-4639-9db3-dde1416a617c', 1, 'i', 'test', '2016-04-05 07:28:10.548');
INSERT INTO party_role (party_id, type_code, rowidentifier, rowversion, change_action, change_user, change_time) VALUES ('6324b8c5-bc4b-4c28-9eba-d58ef1ea1377', 'applicant', 'f5f72c6e-5ae7-44b9-93e3-895086f23c16', 1, 'i', 'test', '2016-04-05 16:54:16.748');


ALTER TABLE party_role ENABLE TRIGGER ALL;

--
-- PostgreSQL database dump complete
--

